<!Doctype html>
<html>
     <head>
            <title>Student Management</title>
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" href="{{url('assets/css/bootstrap.min.css')}}">
            <link rel="stylesheet" href="{{url('assets/css/dataTable.css')}}">
            <link rel="stylesheet" href="{{url('assets/css/bootstrap-toggle.min.css')}}">
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
            <script type="text/javascript" src="{{url('assets/js/jquery.min.js')}}"></script>
            <script type="text/javascript" src="{{url('assets/js/bootstrap.min.js')}}"></script>
            <script type="text/javascript" src="{{url('assets/js/jquery.dataTables.js')}}"></script>
            <script type="text/javascript" src="{{url('assets/js/bootstrap-toggle.min.js')}}"></script>
     </head>
     <body>
           <a class="btn btn-sm btn-primary btn-default pull-right" href="/show_form" style="margin:15px;">Add Student</a>
           <table id="student_table">
                <thead>
                   <th>Id</th>
                   <th>Student Id</th>
                   <th>Name</th>
                   <th>Email</th>
                   <th>Address</th>
                   <th>City</th>
                   <th>State</th>
                   <th>Country</th>
                   <th>Subject</th>
                   <th>Grade</th>
                   <th>Action</th>
                   <th>Status</th>
                </thead>
                <tbody>
                    @foreach ($students as $student)
                        <tr>
                            <td>{{$student->id }}</td>
                            <td>{{$student->student}}</td>
                            <td>{{$student->name}}</td>
                            <td>{{$student->email}}</td>
                            <td>{{$student->address}}</td>
                            <td>{{$student->city}}</td>
                            <td>{{$student->state}}</td>
                            <td>{{$student->country}}</td>
                            <td>{{$student->subject_name}}</td>
                            <td>{{$student->grade}}</td>
                            <td><a href="/student_edit/{{$student->id}}" data-id={{$student->id}} data-toggle="modal" data-target="#exampleModal{{$student->id}}"> <span class="glyphicon glyphicon-pencil"></span></a>|<a href="/student_delete/{{$student->id}}" class="delete"><span class="glyphicon glyphicon-trash"></span></a></td>
                            <td><input type="checkbox" class="toggle-class" data-toggle="toggle" data-id={{$student->id}} data-style="slow" data-on="Enabled" data-off="Disabled" {{$student->enabled==true?'checked':''}}></td>
                        </tr>
                    @endforeach
                    </tbody>
           </table>

        @foreach ($students as $student)
        <form action="/update_edit/{{$student->id}}" method="post" enctype="multipart/form-data">
        @csrf
        <div class="modal fade" id="exampleModal{{$student->id}}"   tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Edit Student Details</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-6 col-lg-6 col-xl-6">
                                <div class="form-group">
                                    <label class="col-form-label"  for="student">Student Id</label>
                                    <input type="text" name="student" class="form-control @error('student') is-invalid @enderror" placeholder="Please Enter Student Id" value="{{$student->student}}"/>
                                    @error('student')
                                        <div class="alert alert-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>

                            <div class="col-md-6 col-lg-6 col-xl-6">
                                <div class="form-group">
                                    <label class="col-form-label"  for="Name">Name</label>
                                    <input type="text" name="name" class="form-control @error('name') is-invalid @enderror" placeholder="Please Enter Name" value="{{$student->name}}"/>
                                    @error('name')
                                        <div class="alert alert-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 col-lg-6 col-xl-6">
                                <div class="form-group">
                                    <label class="col-form-label"  for="Email">Email</label>
                                    <input type="email" name="email" class="form-control @error('email') is-invalid @enderror" placeholder="Please Enter Email" value="{{$student->email}}"/>
                                    @error('email')
                                    <div class="alert alert-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>

                            <div class="col-md-6 col-lg-6 col-xl-6">
                                <div class="form-group">
                                    <label class="col-form-label"  for="Phone">Phone</label>
                                    <input type="text" name="phone" class="form-control @error('phone') is-invalid @enderror" placeholder="Please Enter Phone" value="{{$student->phone}}"/>
                                    @error('phone')
                                    <div class="alert alert-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 col-lg-6 col-xl-6">
                                <div class="form-group">
                                    <label class="col-form-label"  for="Address">Address</label>
                                    <input type="text" name="address" class="form-control @error('address') is-invalid @enderror" placeholder="Please Enter Address" value="{{$student->address}}"/>
                                    @error('address')
                                    <div class="alert alert-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>

                            <div class="col-md-6 col-lg-6 col-xl-6">
                                <div class="form-group">
                                    <label class="col-form-label"  for="City">City</label>
                                    <input type="text" name="city" class="form-control" placeholder="Please Enter City" value="{{$student->city}}"/>
                                </div>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-md-6 col-lg-6 col-xl-6">
                                <div class="form-group">
                                    <label class="col-form-label"  for="State">State</label>
                                    <input type="text" name="state" class="form-control" placeholder="Please Enter State" value="{{$student->state}}"/>
                                </div>
                            </div>

                            <div class="col-md-6 col-lg-6 col-xl-6">
                                <div class="form-group">
                                    <label class="col-form-label"  for="Country">Country</label>
                                    <input type="text" name="country" class="form-control" placeholder="Please Enter Country" value="{{$student->country}}"/>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 col-lg-6 col-xl-6">
                                <div class="form-group">
                                    <label class="col-form-label"  for="Subject">Subject</label>
                                    <select name="subject_name" class="form-control @error('subject_name') is-invalid @enderror" aria-placeholder="Select The subject">
                                        <option value="English">English</option>
                                        <option value="Maths">Maths</option>
                                        <option value="science">Science</option>
                                        <option value="Social">Social</option>
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-6 col-lg-6 col-xl-6">
                                <div class="form-group">
                                    <label class="col-form-label"  for="Grade">Grade</label>
                                    <input type="text" name="grade"  class="form-control @error('grade') is-invalid @enderror" placeholder="Please Enter Grade" value="{{$student->grade}}"/>
                                    @error('grade')
                                    <div class="alert alert-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  <button type="submit" class="btn btn-primary">Update Student</button>
                </div>
              </div>
            </div>
        </div>
    </form>
    @endforeach

</body>
<script type="text/javascript">
    jQuery(document).ready(function($) {
        $('#student_table').DataTable();
    } );
</script>
<script type="text/javascript">
    $(document).ready(function(){
    $("a.delete").click(function(e){
        if(!confirm('Are you sure want delete the student?')){
            e.preventDefault();
            return false;
        }
        return true;
    });
});
</script>
<script>
    $(function() {
      $('#toggle-two').bootstrapToggle({
        on: 'Enabled',
        off: 'Disabled'
      });
    })
  </script>
<script>
    $('.toggle-class').on('change',function(){
        var status = $(this).prop('checked')== true ? 1:0;
        var student_id = $(this).data('id');
                $.ajax({
                type:'GET',
                url:'{{route('student_status')}}',
                dataType:'json',
                data:{
                    'status':status,
                    'student_id':student_id
                },
                success:function(){
                    alert('Student Status is Updated');
                }
            });
            return true;
    })
</script>

</html>
