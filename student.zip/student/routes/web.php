<?php

use App\Http\Controllers\StudentController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/',[StudentController::class,'student_list']);
Route::get('/show_form',[StudentController::class,'show_form']);
Route::post('/save_list',[StudentController::class,'save_list']);
Route::get('/student_edit/{id}',[StudentController::class,'student_edit']);
Route::post('/update_edit/{id}',[StudentController::class,'update_edit']);
Route::get('/student_delete/{id}',[StudentController::class,'student_delete']);
ROUTE::get('/student_status',[StudentController::class,'student_status'])->name('student_status');

