<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Date;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;

class StudentController extends Controller
{
    public function student_list(){
        $student=DB::select('select * from student as s,subject as sub where s.id = sub.id');
        return view('student_list',['students'=>$student]);
    }
    public function show_form(){
        return view('save_list');
    }
    public function save_list(Request $request){

            $student = $request->input('student');
            $name = $request->input('name');
            $email = $request->input('email');
            $phone = $request->input('phone');
            $address = $request->input('address');
            $city = $request->input('city');
            $state = $request->input('state');
            $country = $request->input('country');
            $subject_name = $request->input('subject_name');
            $grade = $request->input('grade');
            $created_at = Date('Y-m-d H:i:s');
            $updated_at = Date('Y-m-d H:i:s');
            $request->validate([
                'student' => 'required',
                'name' => 'required|max:255',
                'phone' => 'required|min:10',
                'address' => 'required|max:255',
                'email' => 'required|email|max:255',
                'subject_name'=>'required',
                'grade'=>'required',
            ]);

            DB::insert('insert into student (student, name,email,phone,address,city,state,country,created_at,updated_at) values (?, ?,?,?,?,?,?,?,?,?)', [$student,$name,$email,$phone,$address,$city,$state,$country,$created_at,$updated_at]);
            if($student!=''){
                DB::insert('insert into subject(subject_name,mark_scored,grade,created_at,updated_at)values(?,?,?,?,?)',[$subject_name,$student,$grade,$created_at,$updated_at]);
            }

            return Redirect::to('/');


    }

    public function student_edit($id){
        $student = DB::select('select * from student as s,subject as sub where s.id = sub.id and id=?',[$id]);
        return view('student_list',["students"=>$student]);
    }

    public function update_edit(Request $request,$id){
        $student = $request->input('student');
        $name = $request->input('name');
        $email = $request->input('email');
        $phone = $request->input('phone');
        $address = $request->input('address');
        $city = $request->input('city');
        $state = $request->input('state');
        $country = $request->input('country');
        $subject_name = $request->input('subject_name');
        $grade = $request->input('grade');
        $created_at = Date('Y-m-d H:i:s');
        $updated_at = Date('Y-m-d H:i:s');
        DB::update("update student set student=?,name=?,email=?,phone=?,address=?,city=?,state=?,country=?,created_at=?,updated_at=? where id=?",[$student,$name,$email,$phone,$address,$city,$state,$country, $created_at,$updated_at,$id]);
        if($student !=''){
            DB::update("update subject set subject_name=?,grade=?,mark_scored=?,created_at=?,updated_at=? where id=?",[$subject_name,$grade,$student, $created_at,$updated_at,$id]);
        }
        return Redirect::to('/');
    }

    public function student_delete($id){
            DB::delete('delete s,sub from student as s,subject as sub where s.id=sub.id and s.id=?',[$id]);
            return Redirect::to('/');
    }

    public function student_status(Request $request){
        $student_id = $request->student_id;
        $status = $request->status;
        DB::update("update student set enabled=? where id=?",[$status,$student_id]);
        echo'<pre>';
        print_r($student_id);die;


    }
}
