<!Doctype html>
<html>
     <head>
            <title>Student Management</title>
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" href="<?php echo e(url('assets/css/bootstrap.min.css')); ?>">
            <link rel="stylesheet" href="<?php echo e(url('assets/css/dataTable.css')); ?>">
            <link rel="stylesheet" href="<?php echo e(url('assets/css/bootstrap-toggle.min.css')); ?>">
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
            <script type="text/javascript" src="<?php echo e(url('assets/js/jquery.min.js')); ?>"></script>
            <script type="text/javascript" src="<?php echo e(url('assets/js/bootstrap.min.js')); ?>"></script>
            <script type="text/javascript" src="<?php echo e(url('assets/js/jquery.dataTables.js')); ?>"></script>
            <script type="text/javascript" src="<?php echo e(url('assets/js/bootstrap-toggle.min.js')); ?>"></script>
     </head>
     <body>
           <a class="btn btn-sm btn-primary btn-default pull-right" href="/show_form" style="margin:15px;">Add Student</a>
           <table id="student_table">
                <thead>
                   <th>Id</th>
                   <th>Student Id</th>
                   <th>Name</th>
                   <th>Email</th>
                   <th>Address</th>
                   <th>City</th>
                   <th>State</th>
                   <th>Country</th>
                   <th>Subject</th>
                   <th>Grade</th>
                   <th>Action</th>
                   <th>Status</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($student->id); ?></td>
                            <td><?php echo e($student->student); ?></td>
                            <td><?php echo e($student->name); ?></td>
                            <td><?php echo e($student->email); ?></td>
                            <td><?php echo e($student->address); ?></td>
                            <td><?php echo e($student->city); ?></td>
                            <td><?php echo e($student->state); ?></td>
                            <td><?php echo e($student->country); ?></td>
                            <td><?php echo e($student->subject_name); ?></td>
                            <td><?php echo e($student->grade); ?></td>
                            <td><a href="/student_edit/<?php echo e($student->id); ?>" data-id=<?php echo e($student->id); ?> data-toggle="modal" data-target="#exampleModal<?php echo e($student->id); ?>"> <span class="glyphicon glyphicon-pencil"></span></a>|<a href="/student_delete/<?php echo e($student->id); ?>" class="delete"><span class="glyphicon glyphicon-trash"></span></a></td>
                            <td><input type="checkbox" class="toggle-class" data-toggle="toggle" data-id=<?php echo e($student->id); ?> data-style="slow" data-on="Enabled" data-off="Disabled" <?php echo e($student->enabled==true?'checked':''); ?>></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
           </table>

        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form action="/update_edit/<?php echo e($student->id); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="modal fade" id="exampleModal<?php echo e($student->id); ?>"   tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Edit Student Details</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-6 col-lg-6 col-xl-6">
                                <div class="form-group">
                                    <label class="col-form-label"  for="student">Student Id</label>
                                    <input type="text" name="student" class="form-control <?php $__errorArgs = ['student'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Please Enter Student Id" value="<?php echo e($student->student); ?>"/>
                                    <?php $__errorArgs = ['student'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-6 col-lg-6 col-xl-6">
                                <div class="form-group">
                                    <label class="col-form-label"  for="Name">Name</label>
                                    <input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Please Enter Name" value="<?php echo e($student->name); ?>"/>
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 col-lg-6 col-xl-6">
                                <div class="form-group">
                                    <label class="col-form-label"  for="Email">Email</label>
                                    <input type="email" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Please Enter Email" value="<?php echo e($student->email); ?>"/>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-6 col-lg-6 col-xl-6">
                                <div class="form-group">
                                    <label class="col-form-label"  for="Phone">Phone</label>
                                    <input type="text" name="phone" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Please Enter Phone" value="<?php echo e($student->phone); ?>"/>
                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 col-lg-6 col-xl-6">
                                <div class="form-group">
                                    <label class="col-form-label"  for="Address">Address</label>
                                    <input type="text" name="address" class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Please Enter Address" value="<?php echo e($student->address); ?>"/>
                                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-6 col-lg-6 col-xl-6">
                                <div class="form-group">
                                    <label class="col-form-label"  for="City">City</label>
                                    <input type="text" name="city" class="form-control" placeholder="Please Enter City" value="<?php echo e($student->city); ?>"/>
                                </div>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-md-6 col-lg-6 col-xl-6">
                                <div class="form-group">
                                    <label class="col-form-label"  for="State">State</label>
                                    <input type="text" name="state" class="form-control" placeholder="Please Enter State" value="<?php echo e($student->state); ?>"/>
                                </div>
                            </div>

                            <div class="col-md-6 col-lg-6 col-xl-6">
                                <div class="form-group">
                                    <label class="col-form-label"  for="Country">Country</label>
                                    <input type="text" name="country" class="form-control" placeholder="Please Enter Country" value="<?php echo e($student->country); ?>"/>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 col-lg-6 col-xl-6">
                                <div class="form-group">
                                    <label class="col-form-label"  for="Subject">Subject</label>
                                    <select name="subject_name" class="form-control <?php $__errorArgs = ['subject_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" aria-placeholder="Select The subject">
                                        <option value="English">English</option>
                                        <option value="Maths">Maths</option>
                                        <option value="science">Science</option>
                                        <option value="Social">Social</option>
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-6 col-lg-6 col-xl-6">
                                <div class="form-group">
                                    <label class="col-form-label"  for="Grade">Grade</label>
                                    <input type="text" name="grade"  class="form-control <?php $__errorArgs = ['grade'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Please Enter Grade" value="<?php echo e($student->grade); ?>"/>
                                    <?php $__errorArgs = ['grade'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  <button type="submit" class="btn btn-primary">Update Student</button>
                </div>
              </div>
            </div>
        </div>
    </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>
<script type="text/javascript">
    jQuery(document).ready(function($) {
        $('#student_table').DataTable();
    } );
</script>
<script type="text/javascript">
    $(document).ready(function(){
    $("a.delete").click(function(e){
        if(!confirm('Are you sure want delete the student?')){
            e.preventDefault();
            return false;
        }
        return true;
    });
});
</script>
<script>
    $(function() {
      $('#toggle-two').bootstrapToggle({
        on: 'Enabled',
        off: 'Disabled'
      });
    })
  </script>
<script>
    $('.toggle-class').on('change',function(){
        var status = $(this).prop('checked')== true ? 1:0;
        var student_id = $(this).data('id');
                $.ajax({
                type:'GET',
                url:'<?php echo e(route('student_status')); ?>',
                dataType:'json',
                data:{
                    'status':status,
                    'student_id':student_id
                },
                success:function(){
                    alert('Student Status is Updated');
                }
            });
            return true;
    })
</script>

</html>
<?php /**PATH C:\xampp\htdocs\student\resources\views/student_list.blade.php ENDPATH**/ ?>